# Melbourne Rental & Lease Transfer Digest (2026-11-07)

- **Decision Goal**: `Dec 3, 2026` (Current contract ends `Jan 10, 2027`)
- **Move-In Window**: `Dec 5 – Dec 30, 2026`
- **Budget Cap**: `≤ $525/wk` Unfurnished | `≤ $560/wk` Furnished
- **Scanned Live Ads**: `328` | **Strict Hawthorn Matches**: `44`

## Top Matching Entire Properties (Direct Train/Tram to Hawthorn)

| Score | Rent | Type | Suburb & Direct Transit | Station Proximity | Move-In | Direct Link |
| :---: | :---: | :---: | :--- | :--- | :---: | :---: |
| **100%** | $335/wk (Unfurn) | 2BHK 🔄 Lease Transfer | **East Melbourne** (Train / Tram 70, 75, ~8m) | ~280m to Jolimont Station (~4 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345177003) |
| **100%** | $346/wk (Furn) | 3BHK 🔄 Lease Transfer | **Kew** (Tram 16 / Bus 609, ~8m) | ~1420m to Glenferrie Station (or 150m to Kew Tram 109/48) (~18 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1344066228) |
| **100%** | $459/wk (Unfurn) | 2BHK 🔄 Lease Transfer | **Box Hill** (Train, ~15m) | ~560m to Box Hill Station (~7 min walk) | Dec 28, 2026 | [Open Property](https://flatmates.com.au/whole-property-melbourne-box-hill-3128-P2037178) |
| **100%** | $480/wk (Unfurn) | 2BHK 🔄 Lease Transfer | **Surrey Hills** (Train / Tram 70, ~12m) | ~390m to Surrey Hills / Union Station (~5 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345415779) |
| **98%** | $360/wk (Unfurn) | 2BHK 🔄 Lease Transfer | **Clayton** (Train (Pakenham/Cranbourne Line), ~26m) | ~760m to Clayton Station (~10 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345429655) |
| **98%** | $460/wk (Unfurn) | 2BHK 🔄 Lease Transfer | **Nunawading** (Train, ~22m) | ~400m to Nunawading Station (~5 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345410075) |
| **98%** | $460/wk (Unfurn) | 2BHK 🔄 Lease Transfer | **Clayton** (Train (Pakenham/Cranbourne Line), ~26m) | ~650m to Clayton Station (~8 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345385724) |
| **97%** | $346/wk (Unfurn) | 4BHK 🔄 Lease Transfer | **Kew** (Tram 16 / Bus 609, ~8m) | ~1570m to Victoria Park / Glenferrie Stn (Tram at door) (~20 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345020126) |
| **97%** | $433/wk (Unfurn) | 3BHK 🔄 Lease Transfer | **Kew** (Tram 16 / Bus 609, ~8m) | ~510m to Glenferrie Station (via Tram 16) (~6 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345261857) |
| **97%** | $450/wk (Unfurn) | 5BHK 🔄 Lease Transfer | **Camberwell** (Train / Tram 70, 75, ~6m) | ~470m to Camberwell Station (~6 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1338735355) |
| **97%** | $510/wk (Unfurn) | 2BHK 🔄 Lease Transfer | **Box Hill** (Train, ~15m) | ~530m to Box Hill Station (~7 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345371376) |
| **96%** | $462/wk (Unfurn) | 5BHK 🔄 Lease Transfer | **Camberwell** (Train / Tram 70, 75, ~6m) | ~600m to Camberwell Station (~8 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1343106752) |
| **96%** | $525/wk (Unfurn) | 2BHK 🔄 Lease Transfer | **Hawthorn East** (Train / Tram 70, 75, ~4m) | ~320m to Hawthorn / Glenferrie Station (~4 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345525493) |
| **93%** | $385/wk (Unfurn) | 1BHK 🔄 Lease Transfer | **Camberwell** (Train / Tram 70, 75, ~6m) | ~1000m to Camberwell Station (~12 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345000282) |
| **93%** | $388/wk (Unfurn) | 1BHK 🔄 Lease Transfer | **Box Hill** (Train, ~15m) | ~590m to Box Hill Station (~7 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345352136) |
| **93%** | $495/wk (Unfurn) | 2BHK 🔄 Lease Transfer | **Caulfield** (Tram 16, ~20m) | ~710m to Caulfield Station (~9 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345046190) |
| **93%** | $500/wk (Unfurn) | 2BHK 🔄 Lease Transfer | **Clayton South** (Train via Richmond, ~29m) | ~820m to Clayton Station (~10 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345152789) |
| **93%** | $500/wk (Unfurn) | 2BHK 🔄 Lease Transfer | **Blackburn** (Train, ~19m) | ~520m to Blackburn Station (~6 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1344861978) |
| **92%** | $460/wk (Unfurn) | 2BHK 🔄 Lease Transfer | **Boronia** (Train, ~38m) | ~660m to Boronia Station (~8 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345474734) |
| **91%** | $369/wk (Unfurn) | 4BHK 🔄 Lease Transfer | **Blackburn** (Train, ~19m) | ~600m to Blackburn Station (~8 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1343718224) |

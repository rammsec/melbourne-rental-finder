# Melbourne Rental & Lease Transfer Digest (2026-11-10)

- **Decision Goal**: `Dec 3, 2026` (Current contract ends `Jan 10, 2027`)
- **Move-In Window**: `Dec 5 – Dec 30, 2026`
- **Budget Cap**: `≤ $525/wk` Unfurnished | `≤ $560/wk` Furnished
- **Scanned Live Ads**: `277` | **Strict Hawthorn Matches**: `47`

## Top Matching Entire Properties (Direct Train/Tram to Hawthorn)

| Score | Rent | Type | Suburb & Direct Transit | Station Proximity | Move-In | Direct Link |
| :---: | :---: | :---: | :--- | :--- | :---: | :---: |
| **100%** | $459/wk (Unfurn) | 2BHK 🔄 Lease Transfer | **Box Hill** (Train, ~15m) | ~560m to Box Hill Station (~7 min walk) | Dec 28, 2026 | [Open Property](https://flatmates.com.au/whole-property-melbourne-box-hill-3128-P2037178) |
| **98%** | $326/wk (Unfurn) | 2BHK 🔄 Lease Transfer | **South Yarra** (Train (1 stop via Richmond) / Tram, ~12m) | ~900m to South Yarra Station (~11 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345634392) |
| **98%** | $460/wk (Unfurn) | 2BHK 🔄 Lease Transfer | **Nunawading** (Train, ~22m) | ~400m to Nunawading Station (~5 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345410075) |
| **92%** | $430/wk (Unfurn) | 2BHK | **Hawthorn East** (Train / Tram 70, 75, ~4m) | ~280m to Auburn Station (~4 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1329920671) |
| **89%** | $480/wk (Unfurn) | 2BHK | **Surrey Hills** (Train / Tram 70, ~12m) | ~390m to Surrey Hills / Union Station (~5 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345415779) |
| **88%** | $450/wk (Unfurn) | 2BHK | **Melbourne CBD** (Train / Tram 70, 75, ~12m) | ~880m to Flinders Street Station (~11 min walk) | Dec 1, 2026 | [Open Property](https://flatmates.com.au/whole-property-melbourne-3000-P2036856) |
| **88%** | $500/wk (Unfurn) | 2BHK | **Melbourne CBD** (Train / Tram 70, 75, ~12m) | ~880m to Flinders Street Station (~11 min walk) | Dec 1, 2026 | [Open Property](https://flatmates.com.au/whole-property-melbourne-3000-P2043443) |
| **87%** | $500/wk (Unfurn) | 2BHK | **Hawthorn East** (Train / Tram 70, 75, ~4m) | ~300m to Hawthorn / Glenferrie Station (~4 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1336816866) |
| **86%** | $360/wk (Unfurn) | 2BHK | **Clayton** (Train (Pakenham/Cranbourne Line), ~26m) | ~760m to Clayton Station (~10 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345429655) |
| **86%** | $460/wk (Unfurn) | 2BHK | **Clayton** (Train (Pakenham/Cranbourne Line), ~26m) | ~650m to Clayton Station (~8 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345385724) |
| **85%** | $510/wk (Unfurn) | 2BHK | **Box Hill** (Train, ~15m) | ~530m to Box Hill Station (~7 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345371376) |
| **84%** | $520/wk (Unfurn) | 2BHK | **Abbotsford** (Bus 609 / Tram 109+16, ~10m) | ~530m to Collingwood Station (~7 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345615116) |
| **84%** | $525/wk (Unfurn) | 2BHK | **Hawthorn** (Train / Tram 70, 75, 16, ~2m) | ~820m to Hawthorn Station (~10 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1344724355) |
| **84%** | $525/wk (Unfurn) | 2BHK | **Hawthorn East** (Train / Tram 70, 75, ~4m) | ~320m to Hawthorn / Glenferrie Station (~4 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345525493) |
| **82%** | $490/wk (Furn) | 1BHK | **Melbourne CBD** (Train / Tram 70, 75, ~12m) | ~1020m to Flinders Street Station (~13 min walk) | Nov 14, 2026 | [Open Property](https://flatmates.com.au/whole-property-melbourne-3000-P1632304) |
| **81%** | $365/wk (Unfurn) | 1BHK | **Burwood** (Train / Tram 75, ~15m) | ~930m to Burwood Station (Direct Tram 75 at door) (~12 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345295708) |
| **81%** | $370/wk (Furn) | 1BHK | **Burwood** (Train / Tram 75, ~15m) | ~950m to Burwood Station (Direct Tram 75 at door) (~12 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345306240) |
| **81%** | $385/wk (Unfurn) | 1BHK | **Camberwell** (Train / Tram 70, 75, ~6m) | ~1000m to Camberwell Station (~12 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345000282) |
| **81%** | $388/wk (Unfurn) | 1BHK | **Box Hill** (Train, ~15m) | ~590m to Box Hill Station (~7 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1345352136) |
| **81%** | $420/wk (Furn) | 1BHK | **Box Hill** (Train, ~15m) | ~780m to Box Hill Station (~10 min walk) | Dec 2026 | [Open Property](https://www.gumtree.com.au/web/listing/property-for-rent/1332128305) |
